#include <Arduino.h>
#include <esp_sleep.h>

int wakeupCount = 0;
const int ledPin = 2;
const int buttonPin = 15;

void setup() {
  Serial.begin(115200);
  delay(1000);
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
  wakeupCount++;
  Serial.printf("Wakeup count: %d\n", wakeupCount);
  digitalWrite(ledPin, HIGH);
  delay(1000);
  digitalWrite(ledPin, LOW);

  esp_sleep_enable_ext0_wakeup((gpio_num_t)buttonPin, 0);
  Serial.println("Going to sleep now");
  Serial.flush();
  esp_deep_sleep_start();
}

void loop() {
  // This will never be called
}