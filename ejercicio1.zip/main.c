#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "driver/gpio.h"

#define UART_PORT      UART_NUM_2
#define UART_TX_PIN    17
#define UART_RX_PIN    16
#define UART_BUF_SIZE  1024
#define LED_GPIO       GPIO_NUM_2

static uint32_t command_counter = 0;
static bool led_state = false;

/* Inicialización UART2 */
void uart2_init(int baudrate)
{
    uart_config_t uart_config = {
        .baud_rate = baudrate,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };

    uart_driver_install(UART_PORT, UART_BUF_SIZE, 0, 0, NULL, 0);
    uart_param_config(UART_PORT, &uart_config);
    uart_set_pin(UART_PORT, UART_TX_PIN, UART_RX_PIN,
                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

/* Procesamiento de comandos */
void process_command(char *cmd)
{
    command_counter++;

    if (strcmp(cmd, "status") == 0) {
        uart_write_bytes(UART_PORT,
            led_state ? "STATUS: LED ON\r\n" : "STATUS: LED OFF\r\n", 20);
    }
    
}

void app_main(void)
{
    uint8_t data[UART_BUF_SIZE];

    uart2_init(115200);

    gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT);

    uart_write_bytes(UART_PORT, "Sistema UART2 listo\r\n", 21);

    while (1) {
        int len = uart_read_bytes(UART_PORT, data,
                                  UART_BUF_SIZE - 1,
                                  pdMS_TO_TICKS(100));

        if (len > 0) {
            data[len] = '\0';
            data[strcspn((char *)data, "\r\n")] = 0;
            process_command((char *)data);
        }
    }
}